from DMGCN import *
from IMP_GCN import *
# import tensorflow as tf
#
# import os
# os.system(r"python IMP_GCN.py")
# os.system(r"python SHCN.py")
